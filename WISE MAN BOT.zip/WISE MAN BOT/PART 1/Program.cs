﻿using System;
using System.Speech.Synthesis;
using System.Threading.Tasks;

class Program
{
    private static SpeechSynthesizer synthesizer = new SpeechSynthesizer();
    private static string userName;

    static async Task Main()
    {
        synthesizer.SelectVoice("Microsoft David Desktop");
        synthesizer.Rate = 2;

        await SpeakAsync("Yo! What is good! I am Wise Man, your cybersecurity guide. I am here to school you on staying safe in the digital streets. What do they call you?");

        DisplayASCIIArt();
        await InteractWithUser();
    }

    static void DisplayASCIIArt()
    {
        string asciiArt = @"
+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
        .-+---------------+-.
      /  |  [O]     [O]  |  \
     |   |   _________   |   |
     |   |  |_________|  |   |
      \  |  |  _   _  |  |  /
       '-+--|-| | | |-|--+-'
            |  |_| |_|  |
       .----+--[=====]--+----.
      /     |  |     |  |    \
     | [##] |  |_____|  | [##]|
     |======+===========+====|
     |    .-'           '-.  |
     |   /    _________    \ |
      \ /    |_________|    \/
       '------------------------
            |  |       |  |
           [=] |       | [=]
            '--'       '--'
+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+
";
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine(asciiArt);
        Console.ResetColor();
    }

    static async Task InteractWithUser()
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        PrintWithTypingAnimation("Wise Man: Ayyyy! I'm WISE MAN — and I'm here to put you on game about cybersecurity!");
        Console.ResetColor();

        PrintWithTypingAnimation("\nWise Man: Before we get into it, what do they call you? Type your name and let's get acquainted: ");
        userName = Console.ReadLine();

        if (!string.IsNullOrEmpty(userName))
        {
            Console.ForegroundColor = ConsoleColor.Green;
            PrintWithTypingAnimation($"Wise Man: Aye {userName}! You stepped into the right place. Wise Man's got you covered!");
            await SpeakAsync($"Aye {userName}! You stepped into the right place. Let's get it!");
            Console.ResetColor();
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Red;
            PrintWithTypingAnimation("Wise Man: Yo I didn't catch that! Run your name back one more time so we can kick things off!");
            Console.ResetColor();
        }

        await AskHowAreYou();
        await AskQuestions();
    }

    static async Task SpeakAsync(string message)
    {
        await Task.Run(() => synthesizer.SpeakAsync(message));
    }

    static async Task AskHowAreYou()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        PrintWithTypingAnimation($"Wise Man: Aye {userName}, real talk — how you doing today? What's the vibe like?");
        Console.ResetColor();

        Console.Write($"{userName}: ");
        Console.ForegroundColor = ConsoleColor.Blue;
        string response = Console.ReadLine();
        Console.ResetColor();

        if (response.ToLower() == "stop" || response.ToLower() == "exit")
        {
            Console.ForegroundColor = ConsoleColor.Green;
            PrintWithTypingAnimation("Wise Man: Aight, no stress! Catch you on the flip side — stay safe out there!");
            Console.ResetColor();
            Environment.Exit(0);
        }

        if (response.ToLower().Contains("good and you") || response.ToLower().Contains("great and you"))
        {
            Console.ForegroundColor = ConsoleColor.Green;
            PrintWithTypingAnimation($"Wise Man: Aye that's what I like to hear, {userName}! I'm locked in and ready to put you on game!");
        }
        else if (response.ToLower().Contains("good") || response.ToLower().Contains("great"))
        {
            Console.ForegroundColor = ConsoleColor.Green;
            PrintWithTypingAnimation($"Wise Man: That's the energy, {userName}! Let's keep that momentum going and level up your cyber knowledge!");
        }
        else if (response.ToLower().Contains("bad") || response.ToLower().Contains("not good"))
        {
            Console.ForegroundColor = ConsoleColor.Red;
            PrintWithTypingAnimation($"Wise Man: Aw man, my bad to hear that {userName}. Let Wise Man drop some knowledge — might just turn your day around!");
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            PrintWithTypingAnimation($"Wise Man: Heard you loud and clear, {userName}. Either way, Wise Man is in the building and ready to school you!");
        }

        Console.ResetColor();
    }

    static async Task AskQuestions()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        PrintWithTypingAnimation("Wise Man: Aight, let's get into it! What cybersecurity topic you want Wise Man to break down for you?");
        Console.ResetColor();

        PrintWithTypingAnimation("Wise Man: 1. Phishing");
        PrintWithTypingAnimation("Wise Man: 2. Password Security");
        PrintWithTypingAnimation("Wise Man: 3. Two-Factor Authentication");
        PrintWithTypingAnimation("Wise Man: 4. Ransomware");
        PrintWithTypingAnimation("Wise Man: 5. Social Engineering");
        PrintWithTypingAnimation("Wise Man: 6. Safe Internet Browsing");
        PrintWithTypingAnimation("Wise Man: 7. Malware Protection");
        PrintWithTypingAnimation("Wise Man: 8. Cyber Hygiene");

        Console.Write($"{userName}: ");
        Console.ForegroundColor = ConsoleColor.Blue;
        string userQuestion = Console.ReadLine().ToLower();
        Console.ResetColor();

        if (userQuestion == "stop" || userQuestion == "exit")
        {
            Console.ForegroundColor = ConsoleColor.Green;
            PrintWithTypingAnimation("Wise Man: Peace out! Stay secure and keep your digital life on lock!");
            Console.ResetColor();
            Environment.Exit(0);
        }

        if (int.TryParse(userQuestion, out int choice) && choice >= 1 && choice <= 8)
        {
            switch (choice)
            {
                case 1: PhishingResponse(); break;
                case 2: PasswordSafetyResponse(); break;
                case 3: TwoFactorAuthenticationResponse(); break;
                case 4: RansomwareResponse(); break;
                case 5: SocialEngineeringResponse(); break;
                case 6: SafeBrowsingResponse(); break;
                case 7: MalwareResponse(); break;
                case 8: CyberHygieneResponse(); break;
            }
        }
        else
        {
            switch (userQuestion)
            {
                case "phishing": PhishingResponse(); break;
                case "password safety": PasswordSafetyResponse(); break;
                case "two-factor authentication": TwoFactorAuthenticationResponse(); break;
                case "ransomware": RansomwareResponse(); break;
                case "social engineering": SocialEngineeringResponse(); break;
                case "safe browsing": SafeBrowsingResponse(); break;
                case "malware": MalwareResponse(); break;
                case "cyber hygiene": CyberHygieneResponse(); break;
                default:
                    Console.ForegroundColor = ConsoleColor.Red;
                    PrintWithTypingAnimation("Wise Man: Yo that ain't on the list! Pick one of the topics up there and Wise Man will break it down for you.");
                    Console.ResetColor();
                    break;
            }
        }

        await AskNextStep();
    }

    static async Task AskNextStep()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        PrintWithTypingAnimation("Wise Man: You want more knowledge? Type 'menu' to see all the topics again or just type a topic and we keep it moving!");
        Console.ResetColor();
        Console.Write($"{userName}: ");
        Console.ForegroundColor = ConsoleColor.Blue;
        string nextStep = Console.ReadLine();
        Console.ResetColor();

        if (nextStep.ToLower() == "stop" || nextStep.ToLower() == "exit")
        {
            Console.ForegroundColor = ConsoleColor.Green;
            PrintWithTypingAnimation("Wise Man: Aight we done here! Stay sharp, stay safe — Wise Man out!");
            Console.ResetColor();
            Environment.Exit(0);
        }

        if (nextStep.ToLower() == "menu")
        {
            await AskQuestions();
        }
        else
        {
            switch (nextStep.ToLower())
            {
                case "phishing": PhishingResponse(); break;
                case "password safety": PasswordSafetyResponse(); break;
                case "two-factor authentication": TwoFactorAuthenticationResponse(); break;
                case "ransomware": RansomwareResponse(); break;
                case "social engineering": SocialEngineeringResponse(); break;
                case "safe browsing": SafeBrowsingResponse(); break;
                case "malware": MalwareResponse(); break;
                case "cyber hygiene": CyberHygieneResponse(); break;
                default:
                    Console.ForegroundColor = ConsoleColor.Red;
                    PrintWithTypingAnimation("Wise Man: That one ain't in the vault! Stick to the listed topics and Wise Man will school you properly.");
                    Console.ResetColor();
                    break;
            }
            await AskNextStep();
        }
    }

    static void PhishingResponse()
    {
        Console.ForegroundColor = ConsoleColor.Magenta;
        PrintWithTypingAnimation("Wise Man: Aight so phishing is when cyber criminals put on a disguise — they pretend to be your bank, your email provider, even your boss — just to con you into handing over your passwords or personal details.");
        PrintWithTypingAnimation("Wise Man: These scams come through fake emails and sketchy links that look legit. The number one rule? Don't click on anything you weren't expecting, and always double check who's really sending that message before you give up any info.");
        Console.ResetColor();
        AskForFeedback("Phishing");
    }

    static void PasswordSafetyResponse()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        PrintWithTypingAnimation("Wise Man: Real talk — your password is like the key to your whole digital life. If it's weak, you're leaving the door wide open. Mix uppercase, lowercase, numbers and symbols to build something solid that's hard to crack.");
        PrintWithTypingAnimation("Wise Man: And never use the same password on more than one account — that's how one breach becomes ten. Grab a password manager to keep all your strong unique passwords safe without having to memorise them all.");
        Console.ResetColor();
        AskForFeedback("Password Safety");
    }

    static void TwoFactorAuthenticationResponse()
    {
        Console.ForegroundColor = ConsoleColor.Green;
        PrintWithTypingAnimation("Wise Man: Two-Factor Authentication is like putting a deadbolt on top of your regular lock. Even if someone gets your password, they still can't walk through the door without that second verification code.");
        PrintWithTypingAnimation("Wise Man: Switch on 2FA on every account that offers it. And use an authenticator app instead of SMS — text codes can be intercepted but authenticator codes are way harder to steal.");
        Console.ResetColor();
        AskForFeedback("Two-Factor Authentication");
    }

    static void RansomwareResponse()
    {
        Console.ForegroundColor = ConsoleColor.Red;
        PrintWithTypingAnimation("Wise Man: Ransomware is straight up digital kidnapping. This nasty software sneaks onto your device, locks all your files, and then demands you pay up — usually in crypto — before they'll supposedly give your stuff back.");
        PrintWithTypingAnimation("Wise Man: Back your data up on the regular, stay away from suspicious links and random downloads, and keep your antivirus updated. And if it ever hits you — don't pay. Paying doesn't guarantee you'll ever see your files again.");
        Console.ResetColor();
        AskForFeedback("Ransomware");
    }

    static void SocialEngineeringResponse()
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        PrintWithTypingAnimation("Wise Man: Social engineering is mind games — straight up psychological manipulation. Attackers use fear, urgency or fake trust to pressure you into giving up sensitive info or doing something you normally wouldn't do.");
        PrintWithTypingAnimation("Wise Man: Always slow down before you react to any unexpected message or request, even if it looks like it came from someone you know. One quick verification call to the real person can save you from a serious situation.");
        Console.ResetColor();
        AskForFeedback("Social Engineering");
    }

    static void SafeBrowsingResponse()
    {
        Console.ForegroundColor = ConsoleColor.Blue;
        PrintWithTypingAnimation("Wise Man: Safe browsing is about watching every step you take online. Always check for HTTPS in the web address — that padlock symbol means your connection is encrypted and your data isn't just floating out there.");
        PrintWithTypingAnimation("Wise Man: Keep your browser and its plugins updated, avoid downloading files from random sites, and use a VPN whenever you jump on public Wi-Fi so nobody can snoop on what you're doing.");
        Console.ResetColor();
        AskForFeedback("Safe Browsing");
    }

    static void MalwareResponse()
    {
        Console.ForegroundColor = ConsoleColor.Magenta;
        PrintWithTypingAnimation("Wise Man: Malware is a whole family of harmful software designed to mess up, spy on or hijack your device. We're talking viruses that delete your files, spyware that watches everything you do, and Trojans that sneak in pretending to be something normal.");
        PrintWithTypingAnimation("Wise Man: Keep a solid antivirus running at all times, never download anything from a source you don't trust, and always make sure your operating system has the latest security updates installed.");
        Console.ResetColor();
        AskForFeedback("Malware");
    }

    static void CyberHygieneResponse()
    {
        Console.ForegroundColor = ConsoleColor.Green;
        PrintWithTypingAnimation("Wise Man: Cyber hygiene is your daily routine for keeping your digital life clean and secure — just like how you brush your teeth every day without thinking about it. Update your software, use strong passwords, and enable 2FA regularly.");
        PrintWithTypingAnimation("Wise Man: Small consistent habits stack up into serious protection over time. Staying secure online isn't something you do once — it's something you keep doing every single day.");
        Console.ResetColor();
        AskForFeedback("Cyber Hygiene");
    }

    static void AskForFeedback(string topic)
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        PrintWithTypingAnimation($"Wise Man: Aight {userName}, did Wise Man break down {topic} in a way that made sense to you?");
        Console.ResetColor();
        Console.Write($"{userName}: ");
        Console.ForegroundColor = ConsoleColor.Blue;
        string feedback = Console.ReadLine();
        Console.ResetColor();

        if (feedback.ToLower() == "stop" || feedback.ToLower() == "exit")
        {
            Console.ForegroundColor = ConsoleColor.Green;
            PrintWithTypingAnimation("Wise Man: Aight we done here! Stay sharp, stay safe — Wise Man out!");
            Console.ResetColor();
            Environment.Exit(0);
        }

        if (feedback.ToLower().Contains("yes"))
        {
            Console.ForegroundColor = ConsoleColor.Green;
            PrintWithTypingAnimation("Wise Man: Let's go! That's what I'm here for — knowledge is power and you just leveled up!");
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Red;
            PrintWithTypingAnimation("Wise Man: My bad that didn't land the way it should have! Wise Man is always improving — your feedback means a lot and we'll come back stronger!");
            Console.ResetColor();
        }
    }

    static void PrintWithTypingAnimation(string text)
    {
        foreach (char c in text)
        {
            Console.Write(c);
            Task.Delay(60).Wait();
        }
        Console.WriteLine();
    }
}